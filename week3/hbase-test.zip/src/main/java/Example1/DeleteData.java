package Example1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.util.Bytes;

public class DeleteData {

    public static void main(String[] args) throws IOException {

        Configuration conf = HBaseConfiguration.create();
        HTable table = new HTable(conf, "t2");

        // instantiate Delete class
        Delete delete = new Delete(Bytes.toBytes("r"));
        delete.deleteColumn(Bytes.toBytes("f"), Bytes.toBytes("q"));
//        delete.deleteFamily(Bytes.toBytes("f"));

        // delete the data
        table.delete(delete);

        table.close();
        System.out.println("data deleted successfully.....");
    }
}