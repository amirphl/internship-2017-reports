package Example1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class InsertData {

    public static void main(String[] args) throws IOException {

        // instantiate Configuration class
        Configuration config = HBaseConfiguration.create();

        // instantiate HTable class
        HTable hTable = new HTable(config, "t");

        // instantiate Put class
        Put p = new Put(Bytes.toBytes("row2001"));

        // add values using add() method
        p.addColumn(Bytes.toBytes("f1"),
                Bytes.toBytes("name"), Bytes.toBytes("Vivek"));
        p.addColumn(Bytes.toBytes("f1"),
                Bytes.toBytes("age"), Bytes.toBytes("17"));
        p.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("city"),
                Bytes.toBytes("tehran"));
        p.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("country"),
                Bytes.toBytes("IRAN"));
        p.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("email"),
                Bytes.toBytes("vivek@abcd.com"));

        // save the put Instance to the HTable.
        hTable.put(p);
        System.out.println("data inserted successfully");

        // close HTable instance
        hTable.close();
    }
}
