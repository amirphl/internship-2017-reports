import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        // instantiate Configuration class
        Configuration config = HBaseConfiguration.create();

        // Instantiating HbaseAdmin class
        HBaseAdmin admin = new HBaseAdmin(config);

        // Instantiating table descriptor class
        HTableDescriptor tableDescriptor = new
                HTableDescriptor(TableName.valueOf("mytable"));

        // Adding column families to table descriptor
        tableDescriptor.addFamily(new HColumnDescriptor("f1"));

        // Execute the table through admin
        admin.createTable(tableDescriptor);

        System.out.println("Table created");

        // instantiate HTable class
        HTable hTable = new HTable(config, "mytable");

        // instantiate Put class
        Put p = new Put(Bytes.toBytes("row2001"));

        // add values using add() method
        p.addColumn(Bytes.toBytes("f1"),
                Bytes.toBytes("name"), Bytes.toBytes("Vivek"));
        p.addColumn(Bytes.toBytes("f1"),
                Bytes.toBytes("age"), Bytes.toBytes("17"));
        p.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("city"),
                Bytes.toBytes("tehran"));
        p.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("country"),
                Bytes.toBytes("IRAN"));
        p.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("email"),
                Bytes.toBytes("vivek@abcd.com"));

        // save the put Instance to the HTable.
        hTable.put(p);
        System.out.println("data inserted successfully");

        // instantiate Get class
        Get g = new Get(Bytes.toBytes("row2001"));

        // get the Result object
        Result result = hTable.get(g);

        // read values from Result class object
        byte[] name = result.getValue(Bytes.toBytes("f1"), Bytes.toBytes("name"));
        byte[] age = result.getValue(Bytes.toBytes("f1"), Bytes.toBytes("age"));
        byte[] city = result.getValue(Bytes.toBytes("f1"), Bytes.toBytes("city"));
        byte[] country = result.getValue(Bytes.toBytes("f1"), Bytes.toBytes("country"));
        byte[] email = result.getValue(Bytes.toBytes("f1"), Bytes.toBytes("email"));

        System.out.println("name: " + Bytes.toString(name));
        System.out.println("age: " + Bytes.toString(age));
        System.out.println("city: " + Bytes.toString(city));
        System.out.println("country: " + Bytes.toString(country));
        System.out.println("email: " + Bytes.toString(email));
        System.out.println("read done successfully ...");

        // instantiate Delete class
        Delete delete = new Delete(Bytes.toBytes("r"));
        delete.deleteColumn(Bytes.toBytes("f1"), Bytes.toBytes("email"));
        //delete.deleteFamily(Bytes.toBytes("f"));

        // delete the data
        hTable.delete(delete);
        System.out.println("data deleted successfully.....");

        // instantiate the Scan class
        Scan scan = new Scan();

        // scan the columns
        scan.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("q"));

        // get the ResultScanner
        ResultScanner scanner = hTable.getScanner(scan);
        for (Result r = scanner.next(); r != null; r = scanner.next())
            System.out.println("Found row : " + r);

        scanner.close();
        // close HTable instance
        hTable.close();
    }
}
